<?php include 'inc/header.php'; ?>



    <!-- CONFERENCE INFO START -->

            <div class="container mywrapper">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-xxl-12 col-12 ">
                  <h2 class="text-center">Steering Committee</h2>
                  <div class="reg-content">
                    
                  <p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-align:center;'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";color:#002060;'>Steering Committee</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Chief Patron:&nbsp;</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";margin-left:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Professor Dr. Emran Kabir Chowdhury,</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";margin-left:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Vice Chancellor, Comilla University, Cumilla-3506</span><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><br></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Patron:&nbsp;</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";margin-left:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Professor Dr. Md. Ashaduzzaman,&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";margin-left:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Treasurer, Comilla University, Cumilla-3506</span><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><br></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Co-Patron:</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Md. Shamimul Islam,&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>President, Comilla University Teachers Association, Cumilla-3506</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style="font-size:13px;">&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Professor Dr. Md. Abu Taher,&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Registrar, Comilla University, Cumilla-3506</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Kazi Mohammad Kamal Uddin,&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Proctor, Comilla University, Cumilla-3506</span><span style="font-size:13px;">&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><br></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>General Chair:&nbsp;</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Prof.Vaclav Skala,University of West Bohemia</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Computer Graphics and Visualization</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Faculty of Applied Sciences</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dept.of Computer Science &amp; Engineering</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Czech Republic</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Mohammad Abu Yousuf,</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Professor, Institute of Information Technology,</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Jahangirnagar University, Savar, Dhaka</span><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><br></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>General Co Chair:&nbsp;</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr M Shamim Kaiser,</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Professor, Institute of Information Technology,</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Jahangirnagar University, Savar, Dhaka</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Prof. P.P.Patra,&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Professor and Dean,</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>UPES, Dehradun, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><br></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Honorary Chair:&nbsp;</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Prof. Dr. K K Aggarwal,&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>NBA, Chairman,&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>New Delhi, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr Mohammad Ali Moni</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Senior Research Associate,&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Department of Computer Laboratory</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>European Bioinformatics Institute, University of Cambridge&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Advisory Chair:</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Jung-Sup Um, Professor, Kyungpook National University, South Korea</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Suraiya Jabin, Professor, JMI, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. K V Arya, Professor, IIITM, Gwalior,India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Conference Chair:&nbsp;</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Md Atiqur Rahman Ahad, Senior Member, IEEE</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Professor, Dept. of Electrical and Electronic Engineering&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>University of Dhaka, Bangladesh.</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Specially Appointed Associate Professor,</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dept. of Media Intelligent, Osaka University, Japan</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>TPC Chair:</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr Teoh Teik Toe, Professor, NTU, Singapore</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Thinagaran Perumal, Department of Computer Science, Universiti Putra Malaysia</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Suraiya Jabin, Professor, JMI, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Mansaf Alam, Professor, JMI,India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Nguyen Gia Nhu, Professor, Duy Tan University, Vietnam</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Hussain Falih Mahdi, College of Engineering, University of Diyala, Iraq</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>TPC Co- Chair:</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Bhaskar Mondal, NIT Jamsedpur, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Prabu Mohandas, NIT Calicut, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Sushil Kumar, NIT, Warrangal, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Deepak Gupta, NIT Arunachal Pradesh, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Track Chair:</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Prof. Chidiebere Ugwu, Director, Information &amp; Communication Technology Centre&nbsp;</span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span style='font-size:13px;font-family:"Verdana","sans-serif";'>(ICTC), University of Port Harcourt, Nigeria</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Partha Pakray, NIT, Silchar, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Praveen Kumar, Amity University UttarPradesh, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Publicity Chair:</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Dr. Bhupesh Kumar Singh,Professor, Arba Minch University, Ethiopia</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Dr.Sachi Nandan Mohanty, Post Doc (IIT Kanpur),College of Engineering Pune, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Editorial Board:</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp; &nbsp; &nbsp; &nbsp; Prof. Vaclav Skala,University of West Bohemia, Czech Republic</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp; &nbsp; &nbsp; &nbsp; Prof. T.P Singh, Professor, UPES, Dehardun, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp; &nbsp; &nbsp; &nbsp; Dr. Tanupriya Choudhury, UPES, Dehradun, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp; &nbsp; &nbsp; &nbsp; Dr. Ravi Tomar, UPES, Dehradun, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp; &nbsp; &nbsp; &nbsp; Dr. Md. Abul Bashar,&nbsp;</span><span style='font-size:12px;font-family:"Verdana","sans-serif";'>Dept. of CSE, Comilla University, Bangladesh</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><br></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Special Session Chair:</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;Prof. Subarna Shakya<strong>,&nbsp;</strong>Tribhuvan University, Nepal</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Dr. Sudeshna Chakraborty, Sharda University, India</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><br></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Corporate Chair:</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style='font-size:13px;font-family:"Verdana","sans-serif";'>Mr. Sayantan Chakraborty,&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Technical Director,&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>International Association of Professional and Fellow Engineers-Delaware-USA</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Convener:</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Mr. Partha Chakraborty, HOD, Assistant Professor, Dept of CSE, Comilla University</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Co-Convener:</span></strong></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-size:13px;font-family:"Verdana","sans-serif";'>Md. Zakir Hossain, Assistant Professor, Dept of CSE, Comilla University</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-family:"Segoe UI Historic","sans-serif";color:#050505;'>Al Amin Biswas, Lecturer, Dept. of Computer Science and Engineering,&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-family:"Segoe UI Historic","sans-serif";color:#050505;'>Daffodil International University, Dhaka</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-family:"Segoe UI Historic","sans-serif";color:#050505;'>Md. Sabab Zulfiker, Lecturer, Dept. of Computer Science and Engineering,&nbsp;</span></p>
<p style='margin:0in;margin-bottom:.0001pt;font-size:15px;font-family:"Calibri","sans-serif";text-indent:.5in;'><span style='font-family:"Segoe UI Historic","sans-serif";color:#050505;'>Daffodil International University, Dhaka</span></p>

                 </div>
                </div>
              </div>
            </div>
  

     <!-- CONFERENCE INFO END -->


<?php include 'inc/footer.php'; ?>