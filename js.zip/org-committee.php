<?php include 'inc/header.php'; ?>



    <!-- CONFERENCE INFO START -->

            <div class="container mywrapper">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-xxl-12 col-12 ">
                  <h2 class="text-center">Organising committee</h2>
                  <div class="reg-content">
                
                
                  <p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Organizing Chair: Partha Chakraborty HOD, Department of Computer Science and Engineering, Comilla University, Cumilla</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Organizing Co-Chair: Khairun Nahar Department of Computer Science and Engineering, Comilla University, Cumilla&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Khalil Ahammad Department of Computer Science and Engineering, Comilla University, Cumilla&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Mohibullah Department of Computer Science and Engineering, Comilla University, Cumilla</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;Meskat Jahan Department of Computer Science and Engineering, Comilla University, Cumilla&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Organizing Committee: Md. Zakir Hossain Department of Computer Science and Engineering, Comilla University, Cumilla</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Khairun Nahar Department of Computer Science and Engineering, Comilla University, Cumilla</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Khalil Ahammad Department of Computer Science and Engineering, Comilla University, Cumilla</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Chowdhury Shahriar Muzammel Department of Computer Science and Engineering, Comilla University, Cumilla</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Mohibullah Department of Computer Science and Engineering, Comilla University, Cumilla&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Mahmuda Khatun Department of Computer Science and Engineering, Comilla University, Cumilla&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Nayan Banik Department of Computer Science and Engineering, Comilla University, Cumilla&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Meskat Jahan Department of Computer Science and Engineering, Comilla University, Cumilla&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Aditi Sarker Department of Computer Science and Engineering, Comilla University, Cumilla</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;Publicity and Sponsorship Chair (Local): Chowdhury Shahriar Muzammel Department of Computer Science and Engineering, Comilla University, Cumilla&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Nayan Banik Department of Computer Science and Engineering, Comilla University, Cumilla&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Web Chair: Mahmuda Khatun Department of Computer Science and Engineering, Comilla University, Cumilla</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;</span></p>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>&nbsp;Aditi Sarker Department of Computer Science and Engineering, Comilla University, Cumilla</span></p>




                 </div>
                </div>
              </div>
            </div>
  

     <!-- CONFERENCE INFO END -->


<?php include 'inc/footer.php'; ?>