<?php include 'inc/header.php'; ?>



    <!-- CONFERENCE INFO START -->

            <div class="container mywrapper">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-xxl-12 col-12 ">
                  <h2 class="text-center">Student Organizing committee</h2>
                  <div class="reg-content" style="height: 100vh;">
                
<p>  Dr. Osamah Ibrahim Khalaf , Al-Nahrain University - College of Information Engineering , Baghdad, Iraq.</p>

                 </div>
                </div>
              </div>
            </div>
  

     <!-- CONFERENCE INFO END -->


<?php include 'inc/footer.php'; ?>