<?php include 'inc/header.php'; ?>



    <!-- CONFERENCE INFO START -->

            <div class="container mywrapper">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-xxl-12 col-12 ">
                  <h2 class="text-center">International Advisory</h2>
                  <div class="reg-content">
                
                  <table class="table">
    <tbody>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-bottom:  none;padding:0in 5.4pt 0in 5.4pt;height:13.8pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><strong><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Full Name</span></strong></p>
            </td>
            <td style="width:103.0pt;border-top:solid windowtext 1.0pt;border-left:none;border-bottom:none;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.8pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><strong><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Designation</span></strong></p>
            </td>
            <td style="width:312.6pt;border-top:solid windowtext 1.0pt;border-left:none;border-bottom:none;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.8pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><strong><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Affiliation</span></strong></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border-top:solid windowtext 1.0pt;border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.8pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Md. Atiqur Rahman Ahad</span></p>
            </td>
            <td style="width:103.0pt;border-top:solid windowtext 1.0pt;border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.8pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Associate Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:solid windowtext 1.0pt;border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.8pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Osaka University School of Science Graduate School of Science, Japan</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border-top:solid windowtext 1.0pt;border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.8pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'> Dr. Mohammad Ali Moni,</span></p>
            </td>
            <td style="width:103.0pt;border-top:solid windowtext 1.0pt;border-left:none;border-bottom:none;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.8pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Associate Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:solid windowtext 1.0pt;border-left:none;border-bottom:none;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.8pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>UNSW: University of New South Wales</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Dr. Alex James</span></p>
            </td>
            <td style="width:103.0pt;border:solid windowtext 1.0pt;border-left:none;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">    
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Department Chair</span></p>
            </td>
            <td style="width:312.6pt;border:solid windowtext 1.0pt;border-left:none;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Nazarbayev University,Kazakhstan</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Rami J. Haddad</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Associate Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Georgia Southern University,USA</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Pascal LORENZ</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>University of Haute Alsace,France</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Anouar ABTOY</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor of IT</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>National School of Applied Sciences of Tetouan, Abdelmalek Essaadi University, Morocco</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Klaus David</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>University of Kassel, Germany</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Prof. Rajkumar Buyya</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor and Director of the Cloud Computing and Distributed Systems (CLOUDS) Laboratory at the University of Melbourne, Australia</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Prof. Subramaniam Ganesan</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor of Electrical and Computer Engineering, Oakland University, Rochester, USA</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>&nbsp;Sheng-Lung Peng</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor,Department of Computer Science and Information Engineering,National Dong Hwa University,Hualien, Taiwan</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Chuan-Ming Liu</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor, Dept. of Computer Science and Information Engineering,Head, Extension Education Center,National Taipei University of Technology (Taipei Tech),Taipei, TAIWAN</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>&nbsp;Yagya D Sharma</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Senior Engineering Manager</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Senior Engineering Manager- Commercial and Defense Products at OSI Systems,Hawthorne, California,USA</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Prof. Daniel Thalmann</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Honorary Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Honorary Professor at EPFL, Switzerland, and Director of Research Development at MIRALab Sarl</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Raja Kumar Murugesan</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Associate Professor of Computer Science<br>&nbsp;Head of Research, Faculty of Innovation and Technology</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>TAYLOR&rsquo;S UNIVERSITY lakeside Campus<br>&nbsp;No.1, Jalan Taylor&rsquo;s, 47500 Subang Jaya<br>&nbsp;Selangor, Malaysia</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Takfarinas Saber</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Assistant Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>School of Computer Scinece,University College Dublin</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Prof. Marcin Paprzycki</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Associate Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Systems Research Institute, Polish Academy of Sciences, ul. Newelska 6, 01-447 Warsaw, Poland</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>&nbsp;Thinagaran Perumal&nbsp;</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Senior Lecturer</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Universiti Putra Malaysia (UPM),Malaysia</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Mohamed Elhoseny</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Assistant Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Faculty of Computers and Information,Mansoura University,Egypt.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Prof. Xavier Fernando</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Ryerson University,Canada</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Prof. Vincenzo Piuri</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Universita&apos; degli Studi di Milano<br>&nbsp;Dipartimento di Informatica<br>&nbsp;Via Celoria 18, 20133 Milano, Italy</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>&nbsp;Sugam Sharma</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Assistant Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Iowa State University, USA</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Sri Devi Ravana</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Associate Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Department of Information Systems<br>&nbsp;Faculty of Computer Science &amp; Information Technology<br>&nbsp;University of Malaya</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Hari Mohan Pandey</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Associate Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Edge Hill University United Kingdom</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Utku Kose&nbsp;</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Associate Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Suleyman Demirel University Kazakhstan</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Raja Kumar Murugesan</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Head of Research, Faculty of Innovation and Technology</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Taylor&apos;s University, Malaysia</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Lailatul Qadri Zakaria</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>International Program Coordinator,Assistant Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Center for Artificial Intelligence Technology,Malaysia</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Chin-Chen Chang</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Chair professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Department of Information Engineering and Computer Science, Feng Chia University,Taiwan</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Du Huynh</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Senior Lecturer</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>The University of Western Australia</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>&nbsp;Jafar A. Alzubi</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Associate Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>School of Engineering<br>&nbsp;Al-Balqa Applied University<br>&nbsp;Salt, 19117<br>&nbsp;Jordan</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Nguyen Gia Nhu</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Dean of Graduate School</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>DuyTan University,Vietnam</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Sanath Sukumaran</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Associate Professor and Enterprise and Industry Liaison</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>School of Computing and IT, Faculty of Innovation and Technology, <br>&nbsp;Taylor&rsquo;s University, No. 1, Jalan Taylor&rsquo;s, 47500 Subang Jaya, Selangor, Malaysia</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Heba Ahmed Hassan&nbsp;</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Associate Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Faculty of Engineering, Cairo University, Giza 12613, Egypt<br>&nbsp;SMIEEE, MIET, Associate Fellow of the Higher Education Academy-United Kingdom<br>&nbsp;Former Dean, College of Engineering - Dhofar University, Salalah, Sultanate of Oman</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Ridha Khedri</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>McMaster University,Canada</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Subarna Shakya</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Institute of Engineering, Tribhuvan University,Nepal</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Azween Bin Abdullah&nbsp;</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor&nbsp;</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Faculty of Innovation and Technology<br>&nbsp;School of Computing and IT<br>&nbsp;Taylors University, Malaysia</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Hung-Yu Kao&nbsp;</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Director of Institute of Medical Informatics (IMI)</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>National Cheng Kung University,Taiwan</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Chiou-Shann Fuh</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor&nbsp;</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Department of Computer Science and Information Engineering<br>&nbsp;National Taiwan University,Taiwan</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>David Asirvatham</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor &nbsp;and Executive Dean</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Taylor&apos;s University, Malaysia</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Adheesh Budree</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Senior Lecturer</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>University of Cape Town,South Africa</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Eyad H. Abed</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>University of Maryland, College Park, USA</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>RUHAIDAH SAMSUDIN</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Senior Lecturer</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>UNIVERSITI TEKNOLOGI MALAYSIA</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>&nbsp;Naveed Anwar</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Senior Lecturer</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Northumbria University,NewCastle</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Sarfraz Nawaz Brohi&nbsp;</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Program Director (Software Engineering)<br>&nbsp;School of Computing &amp; IT &nbsp;</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Faculty of Innovation &amp; Technology<br>&nbsp;Taylor&rsquo;s University, Malaysia. &nbsp;&nbsp;</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Patrick Siarry</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Associate Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Universit&eacute; de Paris 12 (LiSSi, E.A. 3956)</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Valentina E. Balas</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor of Automation and Applied Informatics, Aurel Vlaicu University of Arad, ROMANIA</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:53.35pt;border:solid windowtext 1.0pt;border-top:none;padding:  0in 5.4pt 0in 5.4pt;height:13.8pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'><br>&nbsp;Lei Zhang</span></p>
            </td>
            <td style="width:103.0pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.8pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>Professor</span></p>
            </td>
            <td style="width:312.6pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:13.8pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:"Arial","sans-serif";color:black;'>School of Computer Science and Software Engineering<br>&nbsp;East China Normal University (ECNU)<br>&nbsp;Shanghai 200062, China</span></p>
            </td>
        </tr>
    </tbody>
</table>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'>&nbsp;</p>



                 </div>
                </div>
              </div>
            </div>
  

     <!-- CONFERENCE INFO END -->


<?php include 'inc/footer.php'; ?>