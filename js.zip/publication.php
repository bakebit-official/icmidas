<?php include 'inc/header.php'; ?>



    <!-- CONFERENCE INFO START -->

            <div class="container mywrapper">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-xxl-12 col-12 ">
                  <h2 class="text-center">Publication</h2>
                  <div class="reg-content">
                    <p>
                    All accepted and presented papers will be Submitted to one of the following series for inclusion, the decision will be communicated based on review process to the authors.
                    </p>

                    <br>
                    <br>
                    <img src="images/icon/springer.jpg" alt="">

                 </div>
                </div>
              </div>
            </div>
  

     <!-- CONFERENCE INFO END -->


<?php include 'inc/footer.php'; ?>