<?php include 'inc/header.php'; ?>



    <!-- CONFERENCE INFO START -->

            <div class="container mywrapper">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-xxl-12 col-12 ">
                  <h2 class="text-center">Speical Session</h2>
                  <div class="reg-content">
                    <p>
                    Speical Session will be announced soon.
                    </p>
                 </div>
                </div>
              </div>
            </div>
  

     <!-- CONFERENCE INFO END -->


<?php include 'inc/footer.php'; ?>