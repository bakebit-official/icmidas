<?php include 'inc/header.php'; ?>



    <!-- CONFERENCE INFO START -->

            <div class="container mywrapper">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-xxl-12 col-12 ">
                  <h2 class="text-center">About the conference</h2>
                  <div >
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptas a mollitia fuga, doloremque asperiores repellendus? Optio ab laboriosam earum, quis voluptas reiciendis velit tenetur corporis voluptatem mollitia minima tempora? Nesciunt placeat veritatis vero maiores fugiat voluptates ducimus sapiente recusandae deserunt dolorem, itaque qui molestiae quia reprehenderit doloremque voluptatem numquam, ratione hic, officia dolorum nisi. Atque, quae nisi odio minima iure culpa harum illo obcaecati doloribus ab similique, alias reprehenderit corporis.</p>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, totam.</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae placeat recusandae architecto fugit officia nesciunt quaerat ut doloribus dolore 
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, totam.</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae placeat recusandae architecto fugit officia nesciunt quaerat ut doloribus dolore odit, consequatur quisquam ullam, labore dignissimos blanditiis ducimus quasi ipsam. Est.</p>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, totam.</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae placeat recusandae architecto fugit officia nesciunt quaerat ut doloribus dolore odit, consequatur quisquam ullam, labore dignissimos blanditiis ducimus quasi ipsam. Est.</p>
                 </div>
                </div>
              </div>
            </div>
  

     <!-- CONFERENCE INFO END -->


<?php include 'inc/footer.php'; ?>