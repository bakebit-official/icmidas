<?php include 'inc/header.php'; ?>



    <!-- CONFERENCE INFO START -->

            <div class="container mywrapper">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-xxl-12 col-12 ">
                  <h2 class="text-center">Steering Committee</h2>
                  <div class="reg-content">
                
                  <table class="table">
    <tbody>
        <tr>
            <td style="width: 1.65in;border: 1pt solid windowtext;padding: 0in 5.4pt;height: 13.8pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><strong><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Full Name</span></strong></p>
            </td>
            <td style="width: 13.6677%; border-top: 1pt solid windowtext; border-right: 1pt solid windowtext; border-bottom: 1pt solid windowtext; border-image: initial; border-left: none; padding: 0in 5.4pt; height: 13.8pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><strong><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Designation</span></strong></p>
            </td>
            <td style="width: 61.2539%; border-top: 1pt solid windowtext; border-right: 1pt solid windowtext; border-bottom: 1pt solid windowtext; border-image: initial; border-left: none; padding: 0in 5.4pt; height: 13.8pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><strong><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Affiliation</span></strong></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Mohammad Shorif Uddin</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Imdadul Islam</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Mohammad Zahidur Rahman</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Jugal Krishna Das</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Mohammad Abu Yousuf</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Institute of Information Technology, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>M &nbsp;Shamim Kaiser</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Institute of Information Technology, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md Whaiduzzaman</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Institute of Information Technology, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>M. Arifur Rahman</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Physics, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:17.4pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Mohammad Motiur Rahman</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 17.4pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 17.4pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Mawlana Bhashani Science and Technology University, Santosh, Tangail, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Mostofa Kamal Nasir</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Mawlana Bhashani Science and Technology University, Santosh, Tangail, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Risala Tasin Khan</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Institute of Information Technology Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Kamal Hossain Chowdhury</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Comilla University, Cumilla, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Tofael Ahmed</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Deptartment of Information &amp; Communication Technology, Comilla University, Cumilla, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Saifuddin Md. Tareeq</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, University of Dhaka, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Haider Ali</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, University of Dhaka, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Rezaul Karim</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, University of Dhaka, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Hasanuzzaman</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, University of Dhaka, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Mustafizur Rahman</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, University of Dhaka, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Abu Sayed Md. Mostafizur Rahaman</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md Musfique Anwar</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Ezharul Islam</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>M. Sohel Rahman</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science &amp; Engineering, Bangladesh University of Engineering &amp; Technology (BUET), Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Mostofa Akbar</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science &amp; Engineering, Bangladesh University of Engineering &amp; Technology (BUET), Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Mohammed Eunus Ali</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science &amp; Engineering, Bangladesh University of Engineering &amp; Technology (BUET), Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Tanzima Hashem</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science &amp; Engineering, Bangladesh University of Engineering &amp; Technology (BUET), Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Abu Raihan Mostofa Kamal</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Islamic University of Technology (IUT), Gazipur, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Muhammad Mahbub Alam</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Islamic University of Technology (IUT), Gazipur, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Md. Hasanul Kabir</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Islamic University of Technology (IUT), Gazipur, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Fazlul Hasan Siddiqui</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of CSE, Dhaka University of Engineering &amp; Technology, Gazipur, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>M.M.A. Hashem</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science &amp; Engineering, Khulna University of Engineering &amp; Technology (KUET) Khulna -9203, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>K. M. Azharul Hasan</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science &amp; Engineering, Khulna University of Engineering &amp; Technology (KUET) Khulna -9203, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Kazi Md. Rokibul Alam</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science &amp; Engineering, Khulna University of Engineering &amp; Technology (KUET) Khulna -9203, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Muhammad Aminul Haque Akhand</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science &amp; Engineering, Khulna University of Engineering &amp; Technology (KUET) Khulna -9203, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>A K M Mahbubur Rahman</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science &amp; Engineering, Independent University, Bangladesh, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Ali Shihab Sabbir</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science &amp; Engineering, Independent University, Bangladesh, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Israt Jahan</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>M. Rokonuzzaman</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Electrical &amp; Computer Engineering, North South University, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Mohammad Rashedur Rahman</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Electrical &amp; Computer Engineering, North South University, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Shazzad Hosain</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Electrical &amp; Computer Engineering, North South University, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>M. Mesbahuddin Sarker</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Institute of Information Technology, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Jesmin Akhter</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Institute of Information Technology, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Shamim Al Mamun</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Institute of Information Technology, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Asaduzzaman</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Chittagong University of Engineering and Technology (CUET), Chittagong, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Kaushik Deb</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Chittagong University of Engineering and Technology (CUET), Chittagong, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Humayun Kabir</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Telecommunication Engineering, Noakhali Science and Technology University, Noakhali, Bangladesh</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Morium Akter</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, Jahangirnagar University, Savar, Dhaka-1342, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Bilkis Jamal Ferdosi</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, University of Asia Pacific, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Aloke Kumar Saha</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, University of Asia Pacific, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Hasan Sarwar</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.2in;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, United International University, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width:1.65in;border:solid windowtext 1.0pt;border-top:  none;padding:0in 5.4pt 0in 5.4pt;height:28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Khondaker Abdullah -Al-Mamun</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 28.2pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-family:"Times New Roman","serif";'>Department of Computer Science and Engineering, United International University, Dhaka, Bangladesh.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.6pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Arindam Biswas</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.6pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor&nbsp;</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.6pt;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:12px;font-family:  "Arial","sans-serif";'>KAZI NAZRUL UNIVERSITY<br>&nbsp;ASANSOL</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Karan Verma</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor&nbsp;</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>NIT delhi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Virender Ranga&nbsp;</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor&nbsp;</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Computer Engineering department&nbsp;</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Ritu Sibal</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>NSUT-NSIT Delhi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Shelly Sachdeva</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Head of Department (CSE)</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>NIT,Delhi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>P. Santhi Thilagam</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dept of CSE, NITK SURATHKAL</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Ash Mohammad Abbas</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Aligarh Muslim University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Mohd Zeeshan Ansari</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Jamia Millia Islamia, New Delhi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>MANISH KHARE</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>DA-IICT, Gandhinagar</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Pooja Agarwal</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>PES University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Pradeep Singh</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Head of department</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>National institute of technology Raipur</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>JASVINDER KAUR&nbsp;</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor&nbsp;</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>PDM UNIVERSITY, Bahadurgarh</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>M. MURALI</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>SRM Institute of Science and Technology</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Akriti Nigam</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Birla Institute of Technology, Mesra, Ranchi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Narendra Kohli</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor and Dean</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>HBTU Kanpur</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Asim Banerjee</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>DA-IICT, Gandhinagar</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Ajay Jangra</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Asst. Prof.</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>UIET, Kurukshetra University, Kurukshetra</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>B. Shameedha Begum</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>CSE,NIT Trichi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Sushama Nagpal</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Netaji Subhas University of Technology</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Vikram Mohanlal Agrawal</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Gujarat Technological University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Sanjay Kumar Batish</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Head Computer Centre</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Punjab Engineering College (Deemed to be University) Chandigarh&nbsp;</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Narendra Patel</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>BVM Engg College</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof K K Shukla</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor and Dean (FA)</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Indian Institute of Technology (BHU)</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Zankhana H. Shah</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Gujarat Technological University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Rupa Mehta</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>SVNIT, Surat, Gujarat</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Nilesh B. Prajapati</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Gujarat Technological University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Pritika Bahad</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Lecturer</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>School of Computer Science and IT, Devi Ahilya University, Indore</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>GAGANDEEP</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>PROFESSOR</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Department of Computer Science,Punjabi University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Naresh</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>SRM university&nbsp;</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Amandeep Kaur</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Central University of Punjab</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Baijnath Kaushik</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>School of CSE, Shri Mata Vaishno Devi University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Goutham Reddy Alavalapati</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>National Institute of Technology Andhra Pradesh</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Subhrakanta Panda</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>BITS-PILANI Hyderabad Campus</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Sukhdev Roy</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dayalbagh Educational Institute</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>&nbsp;Manish Sharma</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>PROFESSOR-RESEARCh</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>CHITKARA UNIVERSITY</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Umang Soni</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Asst prof</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>NSUT</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 0.55in;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Mansaf Alam</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.55in; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assoiate Professor and Young Faculty Research Fellow, DeitY, Govt. of India</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.55in; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Jamia Millia Islamia, New Delhi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>S.SELVAPERUMAL&nbsp;</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor &amp; Head&nbsp;</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Syed Ammal Engineering College&nbsp;</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Arun Prakash Agrawal</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Amity University, Noida</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 26.4pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>VIKAS SAXENA</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 26.4pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>PROF.AND HEAD( CSE &amp; IT)</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 26.4pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>JIIT NOIDA</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 26.4pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Shubhalaxmi Kher</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 26.4pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor and Director of Electrical Engineering</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 26.4pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Arkansas State University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Sushama Rani Dutta</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>KL University,Hyderabad</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Vani nikhil laturkar</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Director and professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>SCMS, SRTM University, Nanded, Maharashtra</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>SHAILENDER KUMAR</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>ASSOCIATE PROFESSOR</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>DTU</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Geetika Srivastava</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr.Rammanohar Lohia Avadh University Ayodhya</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Rupal Bhargava</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>BITS Pilani</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Arvind Kumar Upadhyay</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor(CSE)</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Amity University Madhya Pradesh Gwalior</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Kandarpa Kumar Sarma</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor and Head</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>ECE, Gauhati University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Surekha Mariam Varghese</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Mar Athanasius College of Engineering,Kerala</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 26.4pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Shekhappa G. Ankaliki</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 26.4pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof and Head, E &amp; E Engg Department</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 26.4pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>SDM College of Engg &amp; Tech, Dharwad-580 002</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>SYED ARSHAD ALI</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Senior Research Fellow</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Jamia Millia Islamia</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Vikas Kamra</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Ajay Kumar Garg Engineering College, Ghaziabad</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Debajyoti Mukhopadhyay</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Director</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Mumbai University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>K. K. THYAGHARAJAN</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dean (Academic)</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>R.M.D. Engineering College</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Pooja Parnami</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Amity University, Jaipur</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>K THIPPESWAMY</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Visvesvaraya Technological University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 26.4pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>KAMLESH KUMAR SINGH</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 26.4pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>ASSISTANT PROFESSOR-III, ECE</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 26.4pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>ASET, AMITY UNIVERSITY LUCKNOW CAMPUS</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Biswajit Biswas</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Department of Business Administration University of Kalyani University of Kalyani University of Kalyani</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Vikram Bali</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor and HOD(CSE)</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>JSS Academy of Technical Education, Noida</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Senthilkumar Meyyappan</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Nalla Malla Reddy Engineering College, Hyderabad, Telangana, India</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>PRINCE RAJPOOT</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>REC Ambedkar Nagar</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof. Umapada Pal</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor and Head</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>&nbsp;Professor and Head Computer Vision and Pattern Recognition Unit Indian Statistical Institute 203 B. T. Road, Kolkata-700108 India &nbsp;</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>A K Malik</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>B K Birla Institute of Engineering and Technology Pilani</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Rajeev Kumar</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Faculty of Engineering &amp; Computer science, Teerthanker Mahaveer University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Shipra Shukla</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Amity University Uttar Pradesh, Noida UP, India</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 0.55in;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prasenjit Chatterjee</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.55in; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor and HOD, Mechanical Engineering</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.55in; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>MCKV INSTITUTE OF ENGINEERING</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Ashish Payal</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Guru Gobind Singh Indraprastha University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 0.55in;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>PROF. ABDUL QUAIYUM ANSARI</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.55in; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Executive Vice Chairman, IEEE Delhi Section&nbsp;</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 0.55in; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>JAMIA MILLIA ISLAMIA, New Delhi - 110 025, INDIA</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Sandeep Gupta</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>JIMS, Gr. Noida</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.2pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Nitin Tyagi&nbsp;</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.2pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>&nbsp;JIMS, Gr. Noida</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Shekhar Singh Kaushab</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>&nbsp;JIMS, Gr. Noida</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Krishan Kumar Saraswat&nbsp;</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>&nbsp;JIMS, Gr. Noida</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>PROF. Atul Kumar Ojha</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Profesor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>JNU</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof. Ankur Gupta</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Director,MIET</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>MIET, Jammu</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Anchal Garg</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Amity University Taskant</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>PROF. Aditya Tandon&nbsp;</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Researcher, Student MIEEE, Professional MACM, MISOC, MCSI, MIAENG</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>MIAENG</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Devi Prasad Bhukya</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Scientist, DGTC,CSIR Hqrs, New Delhi</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>CSIR Hqrs, New Delhi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. A.K.Mishra&nbsp;</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Principal Scientist (Computer Science) &amp; Head,AKMU,IARI</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>IARI,New Delhi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Manohar Mishra</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>AssociateProfessor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Siksha &apos;O&apos; Anusandhan (Deemed&nbsp;to be University),Bhubaneshwar</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof. Animesh Mukherjee</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'><a href="http://iitkgp.ac.in/"><span style="color:windowtext;text-decoration:none;">Indian Institute of Technology , Kharagpur</span></a></span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>&nbsp;Er. Subodh Prasad</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>G.B.Pant University of agriculture and technology Pantnagar Uttarakhand.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Sanjay Mathur</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>G.B.Pant University of agriculture and technology Pantnagar Uttarakhand.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof. SD Samantaray</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor&nbsp;</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Computer Engg,College of Technology,Pantnagar</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr Harsh Kumar Verma</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor and Head,Department of Computer Science and Engineering</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr B R Ambedkar National Institute of Technology Jalandhar Punjab</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof. (Dr.) Neeraj Kumar</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Senior Member, IEEE, Member IES,Full Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Thapar Institute of Engineering and Technology,Patiala</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr KP Sharma</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>NIT Jalandhar Punjab</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Sudeep Tanwar</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Thapar Institute of Engineering and Technology,Patiala</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof. (Dr.)&nbsp;Vijay&nbsp;Singh&nbsp;Rathore</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>IIS (deemed to be) University, Jaipur</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof. Arpita Aggarwal</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dept of Computer Science,PGDAV College,University of Delhi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. PK Mishra</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>CTO</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Adapro Consulting</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof. Narendra Chaudhari&nbsp;</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>&nbsp;Vice Chancellor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Uttarakhand &nbsp;University</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Ruchika Malhotra</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>DTU New Delhi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Virender Ranga</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>NIT KKR</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>&nbsp;Dr. Shelly Sachdeva</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>NIT Delhi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof. Ritu Sibal</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>NSIT Dwarka Delhi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Anurag Singh&nbsp;</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>NIT Delhi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Sanjay Tanwani</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>School of Computer Science &amp; IT,<br>&nbsp;Devi Ahilya University,Indore</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Sanjay Batish</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Dean Students Affairs (S&amp;O)</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Punjab Engineering College <br>&nbsp;(Deemed to be University)</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Nitin Kumar</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>NIT Uttarakhand</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Sandeep Kumar Garg</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>IIT Roorkee</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Sateesh K Peddoju</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>IIT Roorkee</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Sanjeev kumar</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>IIT Roorkee</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Sukhdev Roy</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'><br>&nbsp;Department of Physics and Computer Science<br>&nbsp;Dayalbagh Educational Institute<br>&nbsp;Dayalbagh, Agra 282 005 India</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Subhrakanta Panda</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>BITS Pilani,Hyderabad</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Anjan K. Ghosh</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor<br>&nbsp;<br>&nbsp;DAIICT<br>&nbsp;<br>&nbsp;Gandhinagar, Gujarat, India 382007.</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Bhaskar Karn</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Birla Institute of Technology<br>&nbsp;Mesra, Ranchi</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Keyur N. Brahmbhatt</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Head &amp; Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>BVM Engineering College</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Challa Rama Krishna</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor &amp; HOD</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>NITTTR (Ministry of HRD, Govt. of India)<br>&nbsp;Sector-26, Chandigarh - 160 019 &nbsp;INDIA</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. K K Shukla</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dean (FA) &amp;<br>&nbsp;Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Indian Institute of Technology (BHU)<br>&nbsp;VARANASI</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Haider Banka</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Indian Institute of Technology (ISM), Dhanbad-826004, India</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Asim Banerjee</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>DA-IICT, Gandhinagar</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof. Chiranjeev Kumar</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dean (Information Systems)</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Indian Institute of Technology (ISM), Dhanbad- 826 004, Jharkhand, India</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Ashalatha Nayak</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor &amp; Head, Department of Computer Science and Engineering</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Manipal Institute of Technology, Manipal Academy of Higher Education (MAHE)<br>&nbsp;<br>&nbsp;Manipal 576104, Karnataka, India</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Aditya Tatu</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>DAIICT, Gandhinagar</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Maitreyee Dutta</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dept. of Computer Science &amp; Engineering,NITTTR, Chandigarh-160019</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Dr. Rakesh Kumar &nbsp;</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor&nbsp;</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Madan Mohan Malaviya University of Technology, Gorakhpur-273010 (U.P.) India</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Mrs. Ranjana S. Jadhav</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Department Of Information Technology &amp; MCA,VIT,Pune</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 13.8pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof. Sudhanshu Tyagi&nbsp;</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.8pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 13.8pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Jan Wy|ykowski University, Polkowice, Poland and Thapar University Patiala</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Soumen Bag</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Assistant Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>IIT ISM Dhanbad</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Prof. Sanjay Kumar Jaha</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Jadavpur University Kolkata</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Jaya Sil</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>IIEST Shibpur Kolkata</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Arindam Biswas</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Professor and Dean</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>IIEST Shibpur Kolkata</span></p>
            </td>
        </tr>
        <tr>
            <td style="width: 1.65in;border-right: 1pt solid windowtext;border-bottom: 1pt solid windowtext;border-left: 1pt solid windowtext;border-image: initial;border-top: none;padding: 0in 5.4pt;height: 15.75pt;vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Ram Sarkar</span></p>
            </td>
            <td style="width: 13.6677%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Associate Professor</span></p>
            </td>
            <td style="width: 61.2539%; border-top: none; border-left: none; border-bottom: 1pt solid windowtext; border-right: 1pt solid windowtext; padding: 0in 5.4pt; height: 15.75pt; vertical-align: bottom;">
                <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:  normal;font-size:15px;font-family:"Siyam Rupali ANSI";'><span style='font-size:13px;font-family:  "Arial","sans-serif";'>Jadavpur University Kolkata</span></p>
            </td>
        </tr>
    </tbody>
</table>
<p style='margin-top:0in;margin-right:0in;margin-bottom:8.0pt;margin-left:0in;line-height:107%;font-size:15px;font-family:"Siyam Rupali ANSI";'>&nbsp;</p>





                 </div>
                </div>
              </div>
            </div>
  

     <!-- CONFERENCE INFO END -->


<?php include 'inc/footer.php'; ?>